package com.mobileutility.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public final class MobileUtilityClient implements ClientModInitializer {
    public static final ClientConfig CONFIG = ClientConfig.load();
    private static KeyBinding menuKey;

    @Override public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobileutility.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.mobileutility"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new ConfigScreen(null));
        });
        HudRenderCallback.EVENT.register((draw, tick) -> renderHud(client(), draw));
    }

    private static MinecraftClient client() { return MinecraftClient.getInstance(); }

    private static void renderHud(MinecraftClient c, DrawContext d) {
        if (c.player == null || c.options.hudHidden) return;
        int x = CONFIG.hudX, y = CONFIG.hudY;
        float s = CONFIG.hudScale;
        int slot = Math.max(16, Math.round(18 * s));
        ItemStack[] items = {
                c.player.getEquippedStack(EquipmentSlot.HEAD), c.player.getEquippedStack(EquipmentSlot.CHEST),
                c.player.getEquippedStack(EquipmentSlot.LEGS), c.player.getEquippedStack(EquipmentSlot.FEET),
                c.player.getMainHandStack(), c.player.getOffHandStack()
        };
        int i = 0;
        for (ItemStack stack : items) {
            if (!CONFIG.hudEnabled) break;
            if (stack.isEmpty()) { i++; continue; }
            int px = CONFIG.vertical ? x : x + i * slot;
            int py = CONFIG.vertical ? y + i * slot : y;
            d.drawItem(stack, px, py);
            if (CONFIG.showCount && stack.getCount() > 1) d.drawText(c.textRenderer, String.valueOf(stack.getCount()), px + 10, py + 10, 0xFFFFFFFF, true);
            if (CONFIG.showDurability && stack.isDamageable()) {
                int max = stack.getMaxDamage(), rem = max - stack.getDamage();
                int pct = max == 0 ? 0 : Math.round(rem * 100f / max);
                d.drawText(c.textRenderer, CONFIG.showPercent ? pct + "%" : rem + "/" + max, px, py + 18, 0xFFFFFFFF, true);
            }
            i++;
        }
        if (CONFIG.espEnabled && c.world != null) {
            // The heavy world rendering is intentionally kept disabled in this first mobile-safe build.
            // Settings are retained so a future rendering backend can be enabled without changing the UI.
        }
    }

    public static int entityCategory(LivingEntity e) {
        if (e instanceof PlayerEntity) return 0;
        if (e instanceof HostileEntity) return 1;
        if (e instanceof AnimalEntity) return 2;
        if (e instanceof PassiveEntity) return 2;
        return 3;
    }
}
