package com.mobileutility.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class ConfigScreen extends Screen {
    private final Screen parent;
    private int tab = 0;
    protected ConfigScreen(Screen parent) { super(Text.literal("Mobile Utility")); this.parent = parent; }
    @Override protected void init() { rebuild(); }
    private void rebuild() {
        clearChildren();
        int w = 180, x = width/2-w/2, y = 42;
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD"), b -> { tab=0; rebuild(); }).dimensions(x, y, 86, 28).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("ESP"), b -> { tab=1; rebuild(); }).dimensions(x+92, y, 86, 28).build());
        if (tab==0) hud(x,y+38,w); else esp(x,y+38,w);
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close()).dimensions(x, height-42, w, 28).build());
    }
    private void hud(int x,int y,int w) {
        addDrawableChild(toggle(x,y,w,"Armor HUD",ClientConfig.CONFIG.hudEnabled,v->{ClientConfig.CONFIG.hudEnabled=v; ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+34,w,"Durability",ClientConfig.CONFIG.showDurability,v->{ClientConfig.CONFIG.showDurability=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+68,w,"Durability %",ClientConfig.CONFIG.showPercent,v->{ClientConfig.CONFIG.showPercent=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+102,w,"Item Count",ClientConfig.CONFIG.showCount,v->{ClientConfig.CONFIG.showCount=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+136,w,"Vertical Layout",ClientConfig.CONFIG.vertical,v->{ClientConfig.CONFIG.vertical=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(new SliderWidget(x,y+170,w,28,Text.literal("Scale"),ClientConfig.CONFIG.hudScale/2) { protected void updateMessage(){setMessage(Text.literal("Scale: "+String.format("%.1fx",ClientConfig.CONFIG.hudScale)));} protected void applyValue(){ClientConfig.CONFIG.hudScale=(float)(value*2);ClientConfig.CONFIG.save();}});
        addDrawableChild(new SliderWidget(x,y+204,w,28,Text.literal("Opacity"),ClientConfig.CONFIG.hudOpacity) { protected void updateMessage(){setMessage(Text.literal("Opacity: "+Math.round(ClientConfig.CONFIG.hudOpacity*100)+"%"));} protected void applyValue(){ClientConfig.CONFIG.hudOpacity=(float)value;ClientConfig.CONFIG.save();}});
    }
    private void esp(int x,int y,int w) {
        addDrawableChild(toggle(x,y,w,"ESP",ClientConfig.CONFIG.espEnabled,v->{ClientConfig.CONFIG.espEnabled=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+34,w,"Players",ClientConfig.CONFIG.players,v->{ClientConfig.CONFIG.players=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+68,w,"Hostile",ClientConfig.CONFIG.hostile,v->{ClientConfig.CONFIG.hostile=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+102,w,"Passive / Animals",ClientConfig.CONFIG.passive,v->{ClientConfig.CONFIG.passive=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+136,w,"Boxes",ClientConfig.CONFIG.boxes,v->{ClientConfig.CONFIG.boxes=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+170,w,"Names",ClientConfig.CONFIG.names,v->{ClientConfig.CONFIG.names=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(toggle(x,y+204,w,"Distance",ClientConfig.CONFIG.distance,v->{ClientConfig.CONFIG.distance=v;ClientConfig.CONFIG.save();}));
        addDrawableChild(new SliderWidget(x,y+238,w,28,Text.literal("Range"),ClientConfig.CONFIG.espRange/128.0) { protected void updateMessage(){setMessage(Text.literal("Range: "+ClientConfig.CONFIG.espRange+" blocks"));} protected void applyValue(){ClientConfig.CONFIG.espRange=Math.max(8,(int)(value*128));ClientConfig.CONFIG.save();}});
    }
    private ButtonWidget toggle(int x,int y,int w,String label,boolean value,java.util.function.Consumer<Boolean> c){return ButtonWidget.builder(Text.literal(label+": "+(value?"ON":"OFF")),b->{boolean n=!value;c.accept(n);rebuild();}).dimensions(x,y,w,28).build();}
    @Override public void close(){if(client!=null)client.setScreen(parent);}
    @Override public void render(DrawContext d,int mouseX,int mouseY,float delta){renderBackground(d,mouseX,mouseY,delta);d.drawCenteredTextWithShadow(textRenderer,title,width/2,18,0xFFFFFFFF);super.render(d,mouseX,mouseY,delta);}
}
