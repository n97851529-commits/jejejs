package com.mobileutility.client;

import java.util.prefs.Preferences;

public final class ClientConfig {
    private static final Preferences P = Preferences.userRoot().node("mobileutility");
    public boolean hudEnabled = true, showDurability = true, showPercent = true, showCount = false, vertical = false;
    public boolean espEnabled = false, players = true, hostile = true, passive = false, neutral = false, other = false;
    public boolean boxes = true, outlines = true, names = true, distance = true, health = true, threeD = false;
    public int hudX = 8, hudY = 8, espRange = 64;
    public float hudScale = 1f, hudOpacity = 1f, espOpacity = 1f, outlineThickness = 1f;

    public static ClientConfig load() {
        ClientConfig c = new ClientConfig();
        c.hudEnabled=P.getBoolean("hudEnabled",c.hudEnabled); c.showDurability=P.getBoolean("showDurability",c.showDurability);
        c.showPercent=P.getBoolean("showPercent",c.showPercent); c.showCount=P.getBoolean("showCount",c.showCount); c.vertical=P.getBoolean("vertical",c.vertical);
        c.espEnabled=P.getBoolean("espEnabled",c.espEnabled); c.players=P.getBoolean("players",c.players); c.hostile=P.getBoolean("hostile",c.hostile); c.passive=P.getBoolean("passive",c.passive);
        c.neutral=P.getBoolean("neutral",c.neutral); c.other=P.getBoolean("other",c.other); c.boxes=P.getBoolean("boxes",c.boxes); c.outlines=P.getBoolean("outlines",c.outlines);
        c.names=P.getBoolean("names",c.names); c.distance=P.getBoolean("distance",c.distance); c.health=P.getBoolean("health",c.health); c.threeD=P.getBoolean("threeD",c.threeD);
        c.hudX=P.getInt("hudX",c.hudX); c.hudY=P.getInt("hudY",c.hudY); c.espRange=P.getInt("espRange",c.espRange); c.hudScale=P.getFloat("hudScale",c.hudScale);
        c.hudOpacity=P.getFloat("hudOpacity",c.hudOpacity); c.espOpacity=P.getFloat("espOpacity",c.espOpacity); c.outlineThickness=P.getFloat("outlineThickness",c.outlineThickness);
        return c;
    }
    public void save() {
        P.putBoolean("hudEnabled",hudEnabled); P.putBoolean("showDurability",showDurability); P.putBoolean("showPercent",showPercent); P.putBoolean("showCount",showCount); P.putBoolean("vertical",vertical);
        P.putBoolean("espEnabled",espEnabled); P.putBoolean("players",players); P.putBoolean("hostile",hostile); P.putBoolean("passive",passive); P.putBoolean("neutral",neutral); P.putBoolean("other",other);
        P.putBoolean("boxes",boxes); P.putBoolean("outlines",outlines); P.putBoolean("names",names); P.putBoolean("distance",distance); P.putBoolean("health",health); P.putBoolean("threeD",threeD);
        P.putInt("hudX",hudX); P.putInt("hudY",hudY); P.putInt("espRange",espRange); P.putFloat("hudScale",hudScale); P.putFloat("hudOpacity",hudOpacity); P.putFloat("espOpacity",espOpacity); P.putFloat("outlineThickness",outlineThickness);
    }
}
